package br.com.benefrancis.documento.model;

public interface DocumentoFederalPessoaJuridica extends Documento{

}
