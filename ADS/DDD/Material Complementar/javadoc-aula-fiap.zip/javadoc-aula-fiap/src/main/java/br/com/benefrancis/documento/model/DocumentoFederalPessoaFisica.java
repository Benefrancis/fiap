package br.com.benefrancis.documento.model;

public interface DocumentoFederalPessoaFisica extends Documento{

}
