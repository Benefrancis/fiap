package br.com.benefrancis.documento.model;

public interface DocumentoFederal extends Documento {

}
