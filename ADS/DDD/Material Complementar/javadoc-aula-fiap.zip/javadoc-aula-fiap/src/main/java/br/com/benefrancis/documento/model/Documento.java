package br.com.benefrancis.documento.model;

/**
 * Interface Documento. A interface nada mais é do que um contrato firmado entre
 * o desenvolvedor e o sistema.
 * 
 * @author Francis
 *
 */
public interface Documento {
	public String getNumero();
}
